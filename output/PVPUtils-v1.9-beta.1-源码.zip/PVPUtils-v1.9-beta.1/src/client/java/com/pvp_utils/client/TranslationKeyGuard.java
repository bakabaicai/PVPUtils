package com.pvp_utils.client;

import com.google.gson.JsonParser;
import com.pvp_utils.PVPUtils;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentContents;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.chat.contents.TranslatableContents;
import net.minecraft.resources.Identifier;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.repository.PackSource;
import net.minecraft.server.packs.resources.IoSupplier;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public final class TranslationKeyGuard {
    private static final Set<String> VANILLA_TRANSLATION_KEYS = loadVanillaTranslationKeys();
    private static final Map<String, Set<String>> SERVER_PACK_TRANSLATION_KEYS = new HashMap<>();
    private static final ThreadLocal<Boolean> FROM_PACKET = ThreadLocal.withInitial(() -> Boolean.FALSE);
    private static final long SERVER_PACK_CACHE_LIFETIME_MS = 5_000L;

    private static Set<String> cachedServerPackKeys = Set.of();
    private static String cachedServerPackSignature = "";
    private static long cachedServerPackTime;

    private TranslationKeyGuard() {
    }

    public static String getSafeText(Component component) {
        return sanitize(component, new IdentityHashMap<>()).getString();
    }

    public static void setFromPacket(boolean fromPacket) {
        FROM_PACKET.set(fromPacket);
    }

    public static boolean isFromPacket() {
        return FROM_PACKET.get();
    }

    /**
     * Clones a component tree decoded from a server packet and marks every contents
     * object inside it. Marked contents are later prevented from resolving client
     * side mod translation keys (see the TranslatableContents mixin).
     */
    public static Component markFromNetwork(Component component) {
        MutableComponent copy = MutableComponent.create(markContents(component.getContents()));
        copy.setStyle(component.getStyle());
        for (Component sibling : component.getSiblings()) {
            copy.append(markFromNetwork(sibling));
        }
        return copy;
    }

    private static ComponentContents markContents(ComponentContents contents) {
        if (contents instanceof TranslationKeyMarker marker) {
            marker.pvp_utils$markTranslationKey();
        }
        return contents;
    }

    private static Component sanitize(Component component, IdentityHashMap<Component, Component> sanitizedComponents) {
        Component cached = sanitizedComponents.get(component);
        if (cached != null) {
            return cached;
        }

        ComponentContents contents = component.getContents();
        MutableComponent sanitized;
        if (contents instanceof TranslatableContents translation) {
            if (isAllowedTranslationKey(translation.getKey())) {
                Object[] arguments = translation.getArgs().clone();
                for (int index = 0; index < arguments.length; index++) {
                    if (arguments[index] instanceof Component argument) {
                        arguments[index] = sanitize(argument, sanitizedComponents);
                    }
                }
                sanitized = MutableComponent.create(new TranslatableContents(translation.getKey(), translation.getFallback(), arguments));
            } else {
                sanitized = Component.literal(translation.getFallback() != null ? translation.getFallback() : translation.getKey());
            }
        } else {
            sanitized = MutableComponent.create(contents);
        }

        sanitized.setStyle(component.getStyle());
        sanitizedComponents.put(component, sanitized);
        for (Component sibling : component.getSiblings()) {
            sanitized.append(sanitize(sibling, sanitizedComponents));
        }
        return sanitized;
    }

    private static Set<String> loadVanillaTranslationKeys() {
        IoSupplier<InputStream> resource = Minecraft.getInstance().getVanillaPackResources().getResource(
                PackType.CLIENT_RESOURCES,
                Identifier.withDefaultNamespace("lang/en_us.json")
        );
        if (resource == null) {
            PVPUtils.LOGGER.warn("Could not find the vanilla English language file");
            return Set.of();
        }

        try (Reader reader = new InputStreamReader(resource.get(), StandardCharsets.UTF_8)) {
            return Set.copyOf(JsonParser.parseReader(reader).getAsJsonObject().keySet());
        } catch (IOException exception) {
            PVPUtils.LOGGER.warn("Could not load vanilla translation keys", exception);
            return Set.of();
        }
    }

    /**
     * A translation key is safe to resolve when it is either shipped by vanilla or
     * provided by a resource pack pushed by the current server. Keys that only exist
     * in the client installation (mod language files) must not be resolved while
     * showing text controlled by the server.
     */
    public static synchronized boolean isAllowedTranslationKey(String key) {
        if (VANILLA_TRANSLATION_KEYS.contains(key)) {
            return true;
        }

        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.getResourceManager() == null) {
            return false;
        }

        Map<String, PackResources> serverPacks = new LinkedHashMap<>();
        minecraft.getResourceManager().listPacks().forEach(pack -> {
            if (pack.location().source() == PackSource.SERVER) {
                serverPacks.put(pack.packId(), pack);
            }
        });

        String signature = String.join(",", serverPacks.keySet());
        long now = System.currentTimeMillis();
        if (!signature.equals(cachedServerPackSignature) || now - cachedServerPackTime > SERVER_PACK_CACHE_LIFETIME_MS) {
            Set<String> translationKeys = new HashSet<>();
            serverPacks.forEach((packId, pack) ->
                    translationKeys.addAll(SERVER_PACK_TRANSLATION_KEYS.computeIfAbsent(packId, ignored -> loadTranslationKeys(pack))));
            SERVER_PACK_TRANSLATION_KEYS.keySet().retainAll(serverPacks.keySet());
            cachedServerPackKeys = Set.copyOf(translationKeys);
            cachedServerPackSignature = signature;
            cachedServerPackTime = now;
        }
        return cachedServerPackKeys.contains(key);
    }

    private static Set<String> loadTranslationKeys(PackResources pack) {
        Set<String> keys = new HashSet<>();
        for (String namespace : pack.getNamespaces(PackType.CLIENT_RESOURCES)) {
            pack.listResources(PackType.CLIENT_RESOURCES, namespace, "lang", (id, resource) -> {
                if (!id.getPath().endsWith(".json")) {
                    return;
                }
                try (Reader reader = new InputStreamReader(resource.get(), StandardCharsets.UTF_8)) {
                    keys.addAll(JsonParser.parseReader(reader).getAsJsonObject().keySet());
                } catch (IOException | IllegalStateException exception) {
                    PVPUtils.LOGGER.warn("Could not load translation keys from server resource pack {}", pack.packId(), exception);
                }
            });
        }
        return Set.copyOf(keys);
    }
}
