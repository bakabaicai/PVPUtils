package com.pvp_utils.client.gui.clickgui.widget;

import io.github.humbleui.types.RRect;

import com.pvp_utils.client.render.skia.SkijaUi;

import com.pvp_utils.client.gui.clickgui.theme.ClickGuiThemeColors;
import io.github.humbleui.skija.Canvas;
import io.github.humbleui.skija.Paint;
import io.github.humbleui.types.Rect;

import java.util.function.Consumer;
import java.util.function.Supplier;

public class SettingSlider extends SettingWidget {
    private final Supplier<Double> getter;
    private final Consumer<Double> setter;
    private final double min, max;
    private final String format;
    private Supplier<Boolean> enabledSupplier = () -> true;
    private boolean dragging = false;
    private double cachedValue = Double.NaN;
    private String cachedText = "";
    private float cachedTextWidth = 0f;
    private final Paint trackPaint = new Paint().setAntiAlias(true);
    private final Paint fillPaint = new Paint().setAntiAlias(true);
    private final Paint thumbPaint = new Paint().setAntiAlias(true);

    public SettingSlider(double min, double max, String format, Supplier<Double> getter, Consumer<Double> setter) {
        this.min = min;
        this.max = max;
        this.format = format;
        this.getter = getter;
        this.setter = setter;
    }

    public SettingSlider setEnabledSupplier(Supplier<Boolean> enabledSupplier) {
        this.enabledSupplier = enabledSupplier == null ? () -> true : enabledSupplier;
        return this;
    }

    private boolean isEnabled() {
        Boolean enabled = enabledSupplier.get();
        return enabled == null || enabled;
    }

    private static final float LABEL_W = 36f;
    private static final float TRACK_W = 120f;

    @Override public float getWidth() { return LABEL_W + 8f + TRACK_W; }
    @Override public float getHeight() { return 20f; }

    @Override
    public void draw(Canvas canvas, float x, float y, float alpha) {
        ClickGuiThemeColors tc = ClickGuiThemeColors.current();
        float enabledAlpha = isEnabled() ? alpha : alpha * 0.4f;
        double value = getter.get();
        if (Double.compare(value, cachedValue) != 0) {
            cachedValue = value;
            cachedText = String.format(format, value);
            cachedTextWidth = SkijaUi.textWidth(cachedText, 11f);
        }
        String val = cachedText;
        float lw = cachedTextWidth;
        SkijaUi.text(canvas, val, x + LABEL_W - lw, (y + 14f) + SkijaUi.textMetrics(11f).getAscent(), SkijaUi.textMetrics(11f).getDescent() - SkijaUi.textMetrics(11f).getAscent(), withAlpha(tc.mutedText, enabledAlpha), 11f);

        float tx = x + LABEL_W + 8f;
        float t = (float)((value - min) / (max - min));
        float trackY = y + 9f;
        float thumbX = tx + t * TRACK_W;

        trackPaint.setColor(withAlpha(tc.scrollbarTrack, enabledAlpha));
        canvas.drawRRect(RRect.makeXYWH(tx, trackY, TRACK_W, 4f, 2f), trackPaint);
        fillPaint.setColor(withAlpha(tc.accent, enabledAlpha));
        canvas.drawRRect(RRect.makeXYWH(tx, trackY, t * TRACK_W, 4f, 2f), fillPaint);
        thumbPaint.setColor(withAlpha(0xFFFFFF, enabledAlpha));
        canvas.drawRRect(RRect.makeXYWH(thumbX - 8f, y + 2f, 16f, 16f, 8f), thumbPaint);
    }

    @Override
    public boolean onClick(float mx, float my, float x, float y, int button) {
        if (button != 0 || !isEnabled()) return false;
        dragging = true;
        applyMouse(mx, x);
        return true;
    }

    @Override
    public boolean onDrag(float mx, float my, float x, float y) {
        if (!dragging || !isEnabled()) return false;
        applyMouse(mx, x);
        return true;
    }

    public void releaseDrag() { dragging = false; }
    public boolean isDragging() { return dragging; }

    private void applyMouse(float mx, float x) {
        float tx = x + LABEL_W + 8f;
        float t = Math.max(0f, Math.min(1f, (mx - tx) / TRACK_W));
        setter.accept(min + t * (max - min));
    }
}
