package com.pvp_utils.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.mojang.serialization.Codec;
import com.pvp_utils.client.TranslationKeyFilteredCodec;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.ComponentSerialization;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.function.Function;

@Mixin(ComponentSerialization.class)
public class ComponentSerializationMixin {

    @WrapOperation(
            method = "<clinit>",
            at = @At(value = "INVOKE", target = "Lcom/mojang/serialization/Codec;recursive(Ljava/lang/String;Ljava/util/function/Function;)Lcom/mojang/serialization/Codec;")
    )
    private static Codec<Component> pvp_utils$wrapComponentCodec(String name, Function<Codec<Component>, Codec<Component>> wrapped, Operation<Codec<Component>> original) {
        return new TranslationKeyFilteredCodec(original.call(name, wrapped));
    }
}
