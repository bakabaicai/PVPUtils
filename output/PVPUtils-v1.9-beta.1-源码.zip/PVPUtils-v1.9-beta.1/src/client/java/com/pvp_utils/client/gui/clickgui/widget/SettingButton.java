package com.pvp_utils.client.gui.clickgui.widget;

import io.github.humbleui.types.RRect;

import com.pvp_utils.client.render.skia.SkijaUi;

import com.pvp_utils.client.gui.clickgui.theme.ClickGuiThemeColors;
import io.github.humbleui.skija.Canvas;
import io.github.humbleui.skija.Paint;

import java.util.function.Supplier;

public class SettingButton extends SettingWidget {
    private final Supplier<String> label;
    private final Runnable action;
    private float pressT = 0f;
    private final Paint bgPaint = new Paint().setAntiAlias(true);
    private String cachedText = "";
    private float cachedTextWidth = 0f;

    public SettingButton(String label, Runnable action) {
        this(() -> label, action);
    }

    public SettingButton(Supplier<String> label, Runnable action) {
        this.label = label;
        this.action = action;
    }

    @Override public float getWidth() { return 100f; }
    @Override public float getHeight() { return 24f; }

    @Override
    public void draw(Canvas canvas, float x, float y, float alpha) {
        pressT += (0f - pressT) * 0.18f;
        int accent = ClickGuiThemeColors.current().accent;
        int bgColor = lerpColor(accent, 0x000000, pressT * 0.18f);
        bgPaint.setColor(withAlpha(bgColor, ClickGuiThemeColors.panelBackgroundAlpha(alpha)));
        canvas.drawRRect(RRect.makeXYWH(x, y, getWidth(), getHeight(), 8f), bgPaint);
        String text = label.get();
        if (!text.equals(cachedText)) {
            cachedText = text;
            cachedTextWidth = SkijaUi.textWidth(text, 11f);
        }
        SkijaUi.text(canvas, text, x + (getWidth() - cachedTextWidth) * 0.5f, (y + 15.5f) + SkijaUi.textMetrics(11f).getAscent(), SkijaUi.textMetrics(11f).getDescent() - SkijaUi.textMetrics(11f).getAscent(), withAlpha(0xFFFFFF, alpha), 11f);
    }

    @Override
    public boolean isAnimating() {
        return pressT > 0.01f;
    }

    @Override
    public boolean onClick(float mx, float my, float x, float y, int button) {
        if (button != 0) return false;
        if (mx < x || mx > x + getWidth() || my < y || my > y + getHeight()) return false;
        pressT = 1f;
        action.run();
        return true;
    }

    private static int lerpColor(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int ar = (a >> 16) & 0xFF, ag = (a >> 8) & 0xFF, ab = a & 0xFF;
        int br = (b >> 16) & 0xFF, bg = (b >> 8) & 0xFF, bb = b & 0xFF;
        return ((int)(ar+(br-ar)*t) << 16) | ((int)(ag+(bg-ag)*t) << 8) | (int)(ab+(bb-ab)*t);
    }
}
